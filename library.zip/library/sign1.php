<?php
session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="lib";
$db=new mysqli($servername,$username,$password,$dbname);
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Retrieve user input
$uname= $_POST['uname'];
$email = $_POST['email'];
$password = $_POST['password'];
$query = "INSERT INTO sign (uname,email,password) VALUES('$uname', '$email','$password')";

if ($db->query($query) === TRUE) {
    // Successful registration
    echo "Registration successful!";
	  $_SESSION['uname'] = $uname;
      $_SESSION['email'] = $email;
	   $_SESSION['password'] = $password;
	   $_SESSION['confirm']=$confirm;	   
        header("Location:login.html"); 
        exit();
} else {
    // Failed registration
    echo "Registration failed. Please try again later.";
}
}

// Close the database connection
$db->close();


?>