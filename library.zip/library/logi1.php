<?php
$servername="localhost";
$username="root";
$password="";
$dbname="lib";
$db=new mysqli($servername,$username,$password,$dbname);
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $uname = $_POST['uname'];
    $password = $_POST['password'];
    $query = "SELECT * FROM sign WHERE uname = '$uname' AND password = '$password'";
    $result = $db->query($query);

    if ($result->num_rows>0) {
        $_SESSION['uname'] = $uname;
		 $_SESSION['password'] = $password;
        header("Location:homelib.html"); 
        exit();
    } else {
        echo "Invalid username or password.";
		header("Location:userinvalid.html");
		exit();
    }
}
?>