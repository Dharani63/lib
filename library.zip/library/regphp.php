<?php
session_start();
$servername="localhost";
$uname="root";
$password="";
$dbname="lib";
$db=new mysqli($servername,$uname,$password,$dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Retrieve user input
$Studentid = $_POST['Studentid'];
$Username = $_POST['Username'];
$Emailid = $_POST['Emailid'];
$Course = $_POST['Course'];
$Gender = $_POST['Gender'];

// Hash the password for security


// Insert user data into the database
$query = "INSERT INTO stureg (Studentid,Username,Emailid,Course,Gender) VALUES ('$Studentid','$Username','$Emailid','$Course','$Gender')";

if ($db->query($query) === TRUE) {
    // Successful registration
    echo "Registration successful!";
	$_SESSION['Studentid'] = $Studentid;
	 $_SESSION['Username'] = $Username;
	   $_SESSION['Emailid'] = $Emailid;
	    $_SESSION['Course'] = $Course;
	     $_SESSION['Gender'] = $Gender;
        header("Location:regsuc.html"); // Redirect to a dashboard or welcome page
        exit();
} else {
    // Failed registration
    echo "Registration failed. Please try again later.";
}
}

// Close the database connection
$db->close();
?>
