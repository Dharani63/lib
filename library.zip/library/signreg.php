<?php
$servername="localhost";
$uname="root";
$password="";
$dbname="lib";
$db=new mysqli($servername,$uname,$password,$dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Retrieve user input
$rollno = $_POST['rollno'];
$Username = $_POST['Username'];
$Emailid = $_POST['Emailid'];
$Course = $_POST['Course'];
$Gender = $_POST['Gender'];

// Hash the password for security



//checking for user already exist are not
$query="select * from stureg where regno='$rollno'";
$result=$db->query($query);
if(mysqli_num_rows($result)==0){

//inserting tha data into table
$query = "INSERT INTO stureg (regno,Username,Emailid,Course,Gender) VALUES ('$rollno','$Username','$Emailid','$Course','$Gender')";

if ($db->query($query) === TRUE) {
    // Successful registration
        registrationsuccess();
       
} else {
    // Failed registration
    registrationfail();
    
}
}
//user already exist
else{
    registrationfail();
}
}

// Close the database connection
$db->close();
?>

<?php
function registrationsuccess(){
echo '
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Successfull</title>
    <link rel="stylesheet" href="boo.css">
</head>
<body>
    <div class="success-box">
        <div class="success-icon">
            <!-- You can replace this with your own SVG or FontAwesome icon -->
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="success-message">
            <h2>Registration Successfull  !!</h2>
            <p><i><b> <br>The Books are Available Now. .</b></i></p>
        </div>
    </div>
    <script>
        setTimeout(function(){window.location.href="homelib.html" },2000);
    </script>
</body>
</html>
';

}




function registrationfail(){
echo '
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rregistration failed</title>
    <link rel="stylesheet" href="boo.css">
</head>
<body>
    <div class="success-box">
        <div class="success-icon">
            <!-- You can replace this with your own SVG or FontAwesome icon -->
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="success-message">
            <h2>Registration Failed  !!</h2>
            <p><i><b> <br>Sorry Some Thing Went Wrong</b></i></p>
        </div>
    </div>
    <script>
        setTimeout(function(){window.location.href="homelib.html" },2000);
    </script>
</body>
</html>
';

}
?>