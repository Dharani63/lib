<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form has been submitted
if(isset($_GET['search'])) {
    $bookname = $_GET['search'];

    // Perform the search query
    $query = "SELECT * FROM books WHERE author LIKE '%$bookname%'";
    $result = mysqli_query($conn, $query);

    // Display the search results
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            echo '<div class="book">';
            echo '<img src="' . $row['image'] . '" alt="' . $row['bookname'] . '">';
            echo '<h3>' . $row['bookname'] . '</h3>';
            echo '<p>' . $row['author'] . '</p>';
            echo '</div>';
        }
    } else {
        echo "No results found.";
    }
}

// Close the database connection
mysqli_close($conn);
?>