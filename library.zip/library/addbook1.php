<?php
// Establish a database connection - Replace these values with your own
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lib";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$bid = $_POST['bid'];
$bookname = $_POST['bookname'];
$edition = $_POST['edition'];
$author = $_POST['author'];


// Insert the book into the database
$sql = "INSERT INTO books (bid, bookname, edition, author) VALUES ('$bid', '$bookname', '$edition', '$author')";

if ($conn->query($sql) === TRUE) {
    echo "Book added successfully!";
	header("location:adsucmsg.html");
		 exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
