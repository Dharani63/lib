 <?php 
   $conn = new mysqli("localhost","root","","lib");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
         }
        if (isset($_POST['search'])){
            $search_str = $_POST['search_str'];
            $sql = "SELECT * FROM books where bookname like '%$search_str%'";
            $result = $conn->query($sql) or die($conn->error);
        }
        else{
            $sql = " SELECT * FROM books ";
            $result = $conn->query($sql);

        }
        $conn->close();

    ?>
	
	 <!--<form action="" class="data-list" method="post">
        
        <div class="filter-container" id="filter-container">
            <label for="filter-input"> Enter Book Name:</label>
            <input type="text" name="search_str" id="filter-input" required>
            <button type="submit"name="search"> Search</button>
        </div>
    </form>-->
