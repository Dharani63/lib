<?php
// Database connection
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to issue a book
function issueBook($bookId, $memberId, $issueDate, $returnDate) {
    global $conn;

    // Check if the book is available
    $query = "SELECT * FROM books WHERE id = $bookId AND status = 'Available'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // Update book status to 'Issued'
        $query = "UPDATE books SET status = 'Issued' WHERE id = $bookId";
        $conn->query($query);

        // Insert book issue record
        $query = "INSERT INTO book_issues (book_id, member_id, issue_date, return_date) VALUES ($bookId, $memberId, '$issueDate', '$returnDate')";
        $conn->query($query);

        echo "Book issued successfully!";
    } else {
        echo "Book is not available for issue.";
    }
}

// Example usage
$bookId = 1;
$memberId = 1;
$issueDate = date('Y-m-d');
$returnDate = date('Y-m-d', strtotime('+14 days'));

issueBook($bookId, $memberId, $issueDate, $returnDate);

$conn->close();
?>