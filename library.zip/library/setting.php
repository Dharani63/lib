<?php
error_reporting(0);
$set=mysqli_connect("localhost","root","","register");
/*
Author
Ashish Vegan(Labade)
technologyvegan@gmail.com
https://www.ashishvegan.com
*/
?>