<?php
// Retrieve form data

// Connect to MySQL
$servername = "localhost";
$dbname = "library";
$dbusername = "root";
$dbpassword = "";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$bid=$_POST['bid'];
	$bookname=$_POST['bookname'];
	$edition=$_POST['edition'];
	$author=$_POST['author'];
	$sql = "SELECT * FROM books WHERE bid='$bid' && bookname='$bookname' && edition='$edition' && author='$author'";
	$result=mysqli_query($conn,$sql);
	$resultcheck=mysqli_num_rows($result);
	if($resultcheck>0)
	{
		echo"The books are available";
		 header("location:bookav.html");
		 exit();
	}
	else
	{
		echo"The books are not available";
		 header("location:bookno.html");
		 exit();
	}
}

$conn->close();
?>