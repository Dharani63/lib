<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get form inputs
$bookid = $_POST['bookid'];
$bookname = $_POST['bookname'];
$issuedate = $_POST['issuedate'];
$duedate = $_POST['duedate'];


// Validate form inputs
if (empty($bookid) || empty($bookname) || empty($issuedate) || empty($duedate)) {
    die("Please fill in all the fields.");
}

// Check if the member and book exist and are available for issue
$memberQuery = "SELECT * FROM tablename WHERE bookid = '$bookid'";
$bookQuery = "SELECT * FROM tablename2 WHERE bookid = '$bookid' AND availability = 1";

$memberResult = mysqli_query($conn, $memberQuery);
$bookResult = mysqli_query($conn, $bookQuery);

if (mysqli_num_rows($memberResult) == 0) {
    die("Invalid  bookid.");
}

if (mysqli_num_rows($bookResult) == 0) {
    die(" book is not available.");
}

// Perform the book issue action
$issueQuery = "INSERT INTO databasename (bookid, bookname, issuedate,duedate) VALUES ('$bookid', '$bookname', '$issuedate','$duedate')";
$updateBookQuery = "UPDATE databasename2 SET availability = 0 WHERE bookid = '$bookid'";

mysqli_query($conn, $issueQuery);
mysqli_query($conn, $updateBookQuery);

// Close the database connection
mysqli_close($conn);

// Redirect to a success page
header("Location: success.html");
exit;
?>