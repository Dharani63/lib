<?php
session_start();
$servername="localhost";
$uname="root";
$password="";
$dbname="register";
$db=new mysqli($servername,$uname,$password,$dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Retrieve user input
$studentid = $_POST['studentid'];
$username = $_POST['username'];
$bookname = $_POST['bookname'];
$issuedate = $_POST['issuedate'];
$duedate = $_POST['duedate'];

// Hash the password for security


// Insert user data into the database
$query = "INSERT INTO issue (studentid,username,bookname,issuedate,duedate) VALUES ('$studentid','$username','$bookname','$issuedate','$duedate')";

if ($db->query($query) === TRUE) {
    // Successful registration
    echo "Registration successful!";
	$_SESSION['studentid'] = $studentid;
	 $_SESSION['username'] = $username;
	   $_SESSION['bookname'] = $bookname;
	    $_SESSION['issuedate'] = $issuedate;
	     $_SESSION['duedate'] = $duedate;
        header("Location:issuc.html"); // Redirect to a dashboard or welcome page
        exit();
} else {
    // Failed registration
    echo "Registration failed. Please try again later.";
}
}

// Close the database connection
$db->close();
?>
