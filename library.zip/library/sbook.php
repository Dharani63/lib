<?php
// Database connection
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form has been submitted
if(isset($_GET['search'])) {
    $searchTerm = $_GET['search'];
    
    // Perform the search query
    $query = "SELECT * FROM books WHERE title LIKE '%$searchTerm%'";
    $result = mysqli_query($conn, $query);

    // Display the search results
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            echo "<h3>".$row['title']."</h3>";
            echo "<p>".$row['author']."</p>";
        }
    } else {
        echo "No results found.";
    }
}

// Close the database connection
mysqli_close($conn);
?>