<?php
// Database connection settings
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the search term from a form or URL parameter
$searchTerm = $_GET['search_term'];

// SQL query to search for books by title
$sql = "SELECT * FROM books WHERE title LIKE '%$searchTerm%'";

// Execute the query
$result = $conn->query($sql);

// Check if any results were found
if ($result->num_rows > 0) {
    // Output data for each book found
    while ($row = $result->fetch_assoc()) {
        echo "Title: " . $row["title"] . "<br>";
        echo "Author: " . $row["author"] . "<br>";
        // Add more fields as needed
        echo "<br>";
    }
} else {
    echo "No books found with that title.";
}

// Close the database connection
$conn->close();
?>

